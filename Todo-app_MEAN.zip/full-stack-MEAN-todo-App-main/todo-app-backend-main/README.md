
```
todo-app
├─ 📁models
│  ├─ 📄Counter.js
│  └─ 📄Task.js
├─ 📁node_modules
├─ 📁routes
│  └─ 📄tasks.js
├─ 📄.gitignore
├─ 📄package-lock.json
├─ 📄package.json
└─ 📄server.js
```
```
todo-app-backend
├─ 📁models
│  ├─ 📄Counter.js
│  └─ 📄Task.js
├─ 📁node_modules
├─ 📁routes
│  └─ 📄tasks.js
├─ 📄.gitignore
├─ 📄README.md
├─ 📄package-lock.json
├─ 📄package.json
└─ 📄server.js
```